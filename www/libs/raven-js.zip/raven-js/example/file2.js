function multiply(a, b) {
	"use strict";
	return a * b;
}
function divide(a, b) {
	"use strict";
	try {
		return multiply(add(a, b), a, b) / c;
	} catch (e) {
		Raven.captureException(e);
	}
}
