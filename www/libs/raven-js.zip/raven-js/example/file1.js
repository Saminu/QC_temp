function add(a, b) {
	"use strict";
	return a + b;
}